

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginValidateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public LoginValidateServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String user = request.getParameter("username");
		String pass = request.getParameter("password");
		PrintWriter out = response.getWriter();
		if(user.equals("Admin")&&pass.equals("Admin")) {
			/* forward is used to forward the request and response object to another servlet 
			 * 
			 * need to mapping in the web.xml
			 * 
			 * */
			RequestDispatcher rd = request.getRequestDispatcher("mess");
			rd.forward(request, response);
		}else {
			out.println("Password is wrong");
			/* 
			 * include is used to send the another
			 * 
			 *  */
			RequestDispatcher rd = request.getRequestDispatcher("LoginPage.html");
			rd.include(request, response);			// To forward the request and response to another servlet
		}
	}
}
