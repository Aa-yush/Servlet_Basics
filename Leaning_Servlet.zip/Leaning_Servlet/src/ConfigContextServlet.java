

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class ConfigContextServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ConfigContextServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			PrintWriter out = response.getWriter();
			out.println("Hii, ");
			
			ServletConfig config = getServletConfig();
			String value = config.getInitParameter("Name");
			out.println(value);
/*			
			ServletContext context = getServletContext();
			String value = context.getInitParameter("Name");
			out.println(value);
			
*/
	}
}
