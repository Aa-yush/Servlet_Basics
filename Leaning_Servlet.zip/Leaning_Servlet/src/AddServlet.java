

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class AddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public AddServlet() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int fno = Integer.parseInt(request.getParameter("fno"));
		int sno = Integer.parseInt(request.getParameter("sno"));
		
		int sum = fno + sno;
		
		Cookie cookie = new Cookie("sqr",sum+"");
		response.addCookie(cookie);
		response.sendRedirect("sq");
		
/*		
 * 		
		HttpSession session = request.getSession();
		session.setAttribute("sqr", sum);
		response.sendRedirect("sq");
		
*/	
/*			
		response.sendRedirect("sq?sqr="+sum); 	//Session Management use Url-Rewritting
		
*/	
		
/*		
 * 		RequestDispatcher is used to send request,response object to another servlet and send data using setAttribute method
 * 
		request.setAttribute("sum",sum);
		RequestDispatcher rd = request.getRequestDispatcher("sq");
		rd.forward(request, response);
*/		
		
	}
}
